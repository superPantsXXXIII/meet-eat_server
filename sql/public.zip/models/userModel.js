// user model


// FIRST TIME WHEN WE USE MYSQL AND NODEJS WE NEED TO RUN THIS CODE AT WORKBENCH:


// // ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '12345678'
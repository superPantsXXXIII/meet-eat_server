const express = require("express");
const sqlCon = require("../db/sqlConnect");
const Joi = require("joi");
const router = express.Router();

router.get("/", async (req, res) => {
  const category = req.query.category;
  let where = "";
  if (category) {
    // where = `WHERE sports = "${category}"`
    where = `WHERE sports = ?`
  }

  const myQuery = `SELECT * FROM players ${where}`;
  sqlCon.query(myQuery, [category] ,(err, results, fields) => {
    if (err) { return res.json(err) }
    res.json(results)
  })
  // res.json({msg:"Players work"});
})



router.get("/test", async (req, res) => {
  const myQuery = "SELECT * FROM players";
  sqlCon.query(myQuery, (err, results, fields) => {
    if (err) { return res.json(err) }
    res.json(results)
  })
  // res.json({msg:"Players work"});
})

router.post("/", async (req, res) => {
  const validBody = validatePlayer(req.body);
  if(validBody.error){
    return res.status(400).json(validBody.error.details)
  }
  // const q = `INSERT INTO players values 
  // (NULL,'${req.body.name}','${req.body.birth_year}','${req.body.sports}')`
  // ? -> למנוע אס קיו אל אניג'קשן של פריצה להאקר לסקריפט שלי
  const q = `INSERT INTO players values 
  (NULL,?,?,?)`;
  const { name, birth_year, sports } = req.body;
  sqlCon.query(q, [name, birth_year, sports], (err, results, fields) => {
    if (err) { return res.json(err) }
    res.json(results)
  })
})



const validatePlayer = (_reqBody) => {
  let joiSchema = Joi.object({
    name: Joi.string().min(2).max(400).required(),
    birth_year: Joi.number().min(1900).max(2100).required(),
    sports: Joi.string().min(2).max(400).required(),
  })
  return joiSchema.validate(_reqBody)
}

module.exports = router;
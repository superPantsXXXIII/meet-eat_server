const mysql = require("mysql2");

const sqlConfig = {
  host:"aws.connect.psdb.cloud",
  user:"8nfptfkne1nwlxicuxev",
  password:"pscale_pw_tbidtqaOB5uInk17O5nWBlSDKr4WYMuoUQCz1ByFeGZ",
  database:"koko",
  ssl:{
    rejectUnauthorized: false
  }
}

const sqlCon = mysql.createConnection(sqlConfig);
sqlCon.connect((err) => {
  if(err){ return console.log(err);}
  console.log("sql connect koko cloud");
})

module.exports = sqlCon;